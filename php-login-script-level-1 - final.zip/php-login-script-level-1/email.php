<?php 


if(isset($POST['email']) && !empty($_POST['email']{})

$nome = addslashes($_POST['name']);
$email = addslashes($_POST['email']);
$mensagem = addslashes($_POST['mesage']);

?>